// import { useContext, useEffect, useState } from "react";
// import "./Step3.css";
// import { useLocation, useNavigate, useParams } from "react-router-dom";
// import DeviceImg from "../../../assets/images/Products/mobile.png";
// import { UserContext } from "../../../Context/contextAPI";
// import { toast } from "react-toastify";
// import Cookies from "js-cookie";
// import api from "../../../Utils/api";
// import { FaAngleLeft, FaAngleRight } from "react-icons/fa";
// import MobileCommonHeadertwo from "../../../Common/MobileCommonHeader/MobileCommonHeadertwo";
// import Login from "../../../ProfileModule/Login/Login";
// import MobileCommonHeaderthree from "../../../Common/MobileCommonHeader/MobileCommonHeaderthree";

// // ====== Transform questions ======
// const transformQuestions = (apiQuestions) =>
//   apiQuestions.map((q) => {
//     let type = "radio";
//     switch (q.questionType) {
//       case "Radio":
//         type = "radio";
//         break;
//       case "Multiple Select":
//         type = "checkbox";
//         break;
//       case "Icon+Radio":
//         type = "icon-radio";
//         break;
//       case "Icon+Select":
//         type = "icon-checkbox";
//         break;
//       case "Dropdown":
//         type = "dropdown";
//         break;
//       default:
//         type = "radio";
//     }

//     const options =
//       q.options?.map((opt, index) => ({
//         id: opt._id || `${q._id}-${index}`,
//         label: opt.label || opt.text || `Option ${index + 1}`,
//         value: String(index),
//         img: opt.iconUrl,
//         description: opt.description || "",
//       })) || [];

//     return {
//       id: q._id,
//       question: q.questionName,
//       questionExplanation: q.questionExplanation,
//       type,
//       options,
//     };
//   });

// const extractAnsweredQuestions = (packageDataArray) => {
//   const results = [];

//   packageDataArray.forEach((pkg) => {
//     const { packageName, packageType, questions, answers } = pkg;

//     const answeredQuestions = Object.entries(answers || {})
//       .map(([questionId, userAnswer]) => {
//         const question = questions.find((q) => q.id === questionId);
//         if (!question) return null;

//         let selectedLabels = [];

//         if (Array.isArray(userAnswer)) {
//           selectedLabels = userAnswer
//             .map((ans) => {
//               const option = question.options.find((o) => o.value === ans);
//               return option?.label;
//             })
//             .filter(Boolean);
//         } else {
//           const option = question.options.find((o) => o.value === userAnswer);
//           if (option) selectedLabels = [option.label];
//         }

//         return {
//           question: question.question,
//           explanation: question.questionExplanation,
//           selectedAnswers: selectedLabels,
//         };
//       })
//       .filter(Boolean);

//     if (answeredQuestions.length > 0) {
//       results.push({
//         packageName,
//         packageType,
//         questions: answeredQuestions,
//       });
//     }
//   });

//   return results;
// };

// function Step3() {
//   let { slug } = useParams();
//   const {
//     packages,
//     allPackageData,
//     setAllPackageData,
//     deviceInfo,
//     userSelection,
//     isLoginModalOpen,
//     setIsLoginModalOpen,
//     answersforMobile,
//     setanswersforMobile,
//   } = useContext(UserContext);

//   const assignedPackages = packages || [];
//   const [currentPackageIndex, setCurrentPackageIndex] = useState(0);
//   const navigate = useNavigate();
//   const [showModal, setShowModal] = useState(false);

//   const currentPackageData = allPackageData[currentPackageIndex] || {};
//   const currentQuestions = currentPackageData?.questions || [];

//   // ===== Conditions pagination =====
//   const [conditionsPagination, setConditionsPagination] = useState({
//     currentPage: 0,
//     questionsPerPage: 3,
//   });

//   const isConditionRelatedPackage =
//     currentPackageData.packageType?.includes("Condition") ||
//     currentPackageData.packageName?.includes("Condition");

//   const conditionsPaginationEnabled =
//     isConditionRelatedPackage &&
//     currentQuestions.length > conditionsPagination.questionsPerPage;

//   const currentConditionsPage = conditionsPagination.currentPage;
//   const conditionsQuestionsPerPage = conditionsPagination.questionsPerPage;
//   const totalConditionsPages = Math.ceil(
//     currentQuestions.length / conditionsQuestionsPerPage
//   );

//   const getPaginatedQuestions = () => {
//     if (!conditionsPaginationEnabled) return currentQuestions;
//     return currentQuestions.slice(
//       currentConditionsPage * conditionsQuestionsPerPage,
//       (currentConditionsPage + 1) * conditionsQuestionsPerPage
//     );
//   };

//   const goToNextConditionsPage = () => {
//     if (!validateCurrentConditionPage()) return;
//     setConditionsPagination((prev) => ({
//       ...prev,
//       currentPage: prev.currentPage + 1,
//     }));
//   };

//   const goToPrevConditionsPage = () => {
//     setConditionsPagination((prev) => ({
//       ...prev,
//       currentPage: prev.currentPage - 1,
//     }));
//   };

//   const resetConditionsPagination = () => {
//     setConditionsPagination((prev) => ({
//       ...prev,
//       currentPage: 0,
//     }));
//   };

//   useEffect(() => {
//     resetConditionsPagination();
//   }, [currentPackageIndex]);

//   const getQuestionNumber = (index) => {
//     if (!conditionsPaginationEnabled) return index + 1;
//     return index + 1 + currentConditionsPage * conditionsQuestionsPerPage;
//   };

//   // ===== Validation =====
//   const validateCurrentConditionPage = () => {
//     const questionsToValidate = getPaginatedQuestions();

//     const unansweredRequired = questionsToValidate.filter(
//       (q) =>
//         (q.type === "radio" || q.type === "icon-radio" || q.type === "dropdown") &&
//         currentPackageData.answers[q.id] === undefined
//     );

//     if (unansweredRequired.length > 0) {
//       toast.error(
//         `Please answer ${unansweredRequired.length} required question(s) before continuing`
//       );
//       return false;
//     }
//     return true;
//   };

//   const validateCurrentPackage = () => {
//     const currentPackage = allPackageData[currentPackageIndex];

//     if (!currentPackage.questions || currentPackage.questions.length === 0) {
//       return true;
//     }

//     if (conditionsPaginationEnabled) {
//       return validateCurrentConditionPage();
//     }

//     const unansweredRequired = currentPackage.questions.filter(
//       (q) =>
//         (q.type === "radio" || q.type === "icon-radio" || q.type === "dropdown") &&
//         currentPackage.answers[q.id] === undefined
//     );

//     if (unansweredRequired.length > 0) {
//       toast.error("Please answer all required questions before continuing");
//       return false;
//     }

//     return true;
//   };

//   // ===== Load questions from packages =====
//   useEffect(() => {
//     if (packages && packages.length > 0) {
//       const transformed = packages.map((pkg) => ({
//         packageId: pkg.packageId._id,
//         packageName: pkg.packageId.packageName,
//         packageType: pkg.packageId.packageType,
//         pageTitle: pkg.packageId.pageTitle,
//         titleExplanation: pkg.packageId.titleExplanation,
//         questions: transformQuestions(pkg.packageId.questions || []),
//         answers: {},
//       }));
//       setAllPackageData(transformed);
//     } else {
//       navigate(`${slug}/${userSelection.variantSlug}`);
//     }
//   }, [assignedPackages]);

//   // ===== Handle option change =====
//   const handleOptionChange = (questionId, optionValue, isMulti) => {
//     setAllPackageData((prev) =>
//       prev.map((pkg, index) => {
//         if (index !== currentPackageIndex) return pkg;

//         const prevAnswers = pkg.answers || {};
//         let updatedAnswers;

//         if (isMulti) {
//           const current = prevAnswers[questionId] || [];
//           updatedAnswers = {
//             ...prevAnswers,
//             [questionId]: current.includes(optionValue)
//               ? current.filter((v) => v !== optionValue)
//               : [...current, optionValue],
//           };
//         } else {
//           updatedAnswers = {
//             ...prevAnswers,
//             [questionId]: optionValue,
//           };
//         }

//         return {
//           ...pkg,
//           answers: updatedAnswers,
//         };
//       })
//     );
//   };

//   // ===== Render options =====
//   const renderOptions = (q) => {
//     const isMulti = q.type === "checkbox" || q.type === "icon-checkbox";
//     const showIcons = q.type === "icon-radio" || q.type === "icon-checkbox";
//     const isDropdown = q.type === "dropdown";
//     const currentAnswers = allPackageData[currentPackageIndex]?.answers || {};
//     const selected = currentAnswers[q.id] || (isMulti ? [] : "");

//     if (isDropdown) {
//       const selectedValue = currentAnswers[q.id] || "";
//       return (
//         <select
//           className="dropdown-select"
//           name={q.id}
//           value={selectedValue}
//           onChange={(e) => handleOptionChange(q.id, e.target.value, false)}
//         >
//           <option value="" disabled>
//             Select an option
//           </option>
//           {q.options.map((opt) => (
//             <option key={opt.id} value={opt.value}>
//               {opt.label}
//             </option>
//           ))}
//         </select>
//       );
//     }

//     return (
//       <div
//         className={`options ${showIcons
//             ? "box-grid icon-option-container"
//             : q.options.some(
//               (opt) =>
//                 (opt.label?.length || 0) > 40 || // 👈 label too long
//                 (opt.description?.length || 0) > 60 // 👈 description too long
//             )
//               ? "long-text"
//               : "short-text"
//           }`}
//       >
//         {q.options.map((opt) => {
//           const isSelected = isMulti
//             ? selected.includes(opt.value)
//             : selected === opt.value;

//           return showIcons ? (
//             <div
//               key={opt.id}
//               className={`select-box ${isSelected ? "selected" : ""}`}
//               onClick={() => handleOptionChange(q.id, opt.value, isMulti)}
//             >
//               {opt.img && (
//                 <div className="icon-space">
//                   <img src={opt.img} alt={opt.label} />
//                 </div>
//               )}
//               <label
//                 className="label-inside-icon"
//                 onClick={(e) => e.stopPropagation()}
//               >
//                 <input
//                   type={isMulti ? "checkbox" : "radio"}
//                   name={q.id}
//                   value={opt.value}
//                   className="custom-radio"
//                   checked={isSelected}
//                   onChange={() => handleOptionChange(q.id, opt.value, isMulti)}
//                 />
//                 <span className="option-text">{opt.label}</span>
//                 {opt.description && (
//                   <p className="option-text-des">{opt.description}</p>
//                 )}
//               </label>
//             </div>
//           ) : (
//             <label
//               key={opt.id}
//               className={`option ${isSelected ? "selected" : ""} option-with-des-box`}
//               onClick={() => handleOptionChange(q.id, opt.value, isMulti)}
//             >
//               <input
//                 type={isMulti ? "checkbox" : "radio"}
//                 name={q.id}
//                 value={opt.value}
//                 checked={isSelected}
//                 onChange={() => handleOptionChange(q.id, opt.value, isMulti)}
//                 className="custom-radio"
//                 onClick={(e) => e.stopPropagation()}
//               />
//               <div className="option-input-flex">
//                 <span className="option-text">{opt.label}</span>
//                 {opt.description && (
//                   <span className="option-text-des">{opt.description}</span>
//                 )}
//               </div>
//             </label>
//           );
//         })}
//       </div>


//     );
//   };

//   // ===== Transform answers for backend =====
//   const transformAnswersForBackend = (answers, questions) => {
//     const transformed = {};
//     Object.entries(answers).forEach(([questionId, answerValue]) => {
//       const question = questions.find((q) => q.id === questionId);
//       if (!question) return;

//       if (Array.isArray(answerValue)) {
//         transformed[questionId] = answerValue.map((val) =>
//           isNaN(val) ? val : Number(val)
//         );
//       } else {
//         transformed[questionId] = isNaN(answerValue)
//           ? answerValue
//           : Number(answerValue);
//       }
//     });
//     return transformed;
//   };

//   // ===== Save and price calculation =====
//   const priceCalculationAndSave = async () => {
//     try {
//       const token = JSON.parse(Cookies.get("auth-token"));
//       if (!token) return;

//       if (!deviceInfo.deviceName) return;

//       if (
//         !userSelection?.cityId ||
//         !userSelection?.cityName ||
//         !userSelection?.wholeVariantId ||
//         !userSelection?.variantId
//       ) {
//         toast.error("Please select city, device name and variant first");
//         return;
//       }

//       const transformedPackageData = allPackageData.map((pkg) => ({
//         ...pkg,
//         answers: transformAnswersForBackend(pkg.answers || {}, pkg.questions),
//       }));

//       console.log("Transformed Package Data for Backend 🤔🤔🤔:", transformedPackageData);

//       const resp = await api.post("/sell-module/user/price-estimation", {
//         packagesAnswer: transformedPackageData,
//         basePrice: 50000,
//         userSelection,
//         deviceName: deviceInfo.deviceName,
//         deviceVariant: deviceInfo.variantDetail,
//       });

//       navigate(`/${slug}/price-summary`);
//     } catch (error) {
//       console.error("Error fetching final price:", error);
//       toast.error("Error fetching final price");
//     }
//   };

//   // ===== Continue / Previous =====
//   const handleContinue = async () => {
//     console.log("Continue clicked");
//     if (!validateCurrentPackage()) return;

//     if (conditionsPaginationEnabled) {
//       if (currentConditionsPage < totalConditionsPages - 1) {
//         goToNextConditionsPage();
//         return;
//       }
//     }

//     if (currentPackageIndex < assignedPackages.length - 1) {
//       setCurrentPackageIndex((i) => i + 1);
//       return;
//     }

//     const savedToken = Cookies.get("auth-token");
//     if (!savedToken) {
//       setIsLoginModalOpen(true);
//       return;
//     }

//     setanswersforMobile(extractAnsweredQuestions(allPackageData));

//     await priceCalculationAndSave();
//   };

//   const handlePrevious = () => {
//     if (conditionsPaginationEnabled && currentConditionsPage > 0) {
//       goToPrevConditionsPage();
//       return;
//     }

//     if (currentPackageIndex === 0) {
//       navigate(`${slug}/${userSelection.variantSlug}`);
//     } else {
//       setCurrentPackageIndex((i) => i - 1);
//     }
//   };

//   const getButtonText = () => {
//     if (conditionsPaginationEnabled) {
//       return currentConditionsPage < totalConditionsPages - 1
//         ? "Next Page"
//         : currentPackageIndex < assignedPackages.length - 1
//           ? "Continue"
//           : "Get Price";
//     }
//     return currentPackageIndex < assignedPackages.length - 1
//       ? "Continue"
//       : "Get Price";
//   };

//   const renderAnsweredQuestions = () => {
//     if (!allPackageData) return null;
//     console.log("All Package Data ◽◽◽:", allPackageData)

//     return allPackageData.map((packageData, index) => {
//       const hasAnswers = packageData.answers && Object.keys(packageData.answers).length > 0;

//       if (!hasAnswers) return null;

//       return (
//         <div key={packageData.packageId} className="package-answers">
//           <h3 className="answer-heading">
//             {`${index + 1}`} {packageData?.packageType || packageData?.packageName}
//           </h3>
//           {Object.entries(packageData.answers).map(([qid, ans], ansIndex) => {
//             const q = packageData.questions.find((q) => q.id === qid);
//             if (!q) return null;

//             let displayValue;
//             if (Array.isArray(ans)) {
//               displayValue = ans
//                 .map((value) => {
//                   const opt = q.options.find((o) => o.value === value);
//                   return opt?.label || value;
//                 })
//                 .filter(Boolean)
//                 .join(", ");
//             } else {
//               const opt = q.options.find((o) => o.value === ans);
//               displayValue = opt?.label || ans;
//             }

//             if (!displayValue) return null;

//             return (
//               <div key={qid} className="answer-item">
//                 <p className="question-text">
//                   {`${ansIndex + 1}. ${q?.question}`}
//                 </p>
//                 <ul className="answer-text">
//                   {displayValue.split(",").map((item, i) => (
//                     <li key={i}>• {item.trim()}</li>
//                   ))}
//                 </ul>
//               </div>
//             );
//           })}
//         </div>
//       );
//     });
//   };

//   return (
//     <>
//       <MobileCommonHeaderthree
//       title = "Calculation"
//        />
//       <section className="form-section mobile-pt-section">
//         <div className="wrapper">
//           {/* Left Side */}

//           <div className="form-left">
//             <div className="device-detail">
//               <img src={deviceInfo?.devicePic || DeviceImg} alt="Device" />
//               <div className="device-name">
//                 <h2>{deviceInfo?.deviceName}</h2>
//                 <span>{deviceInfo?.variantDetail}</span>
//               </div>
//             </div>

//             <div className="form-details">
//               <span>Device Details</span>
//               {renderAnsweredQuestions()}
//             </div>
//           </div>

//           {/* signup modal */}

//           {/* Right Side - remains mostly the same */}
//           <div className="form-right">
//             {/* { isLoginModalOpen && 
//              <Login
//               //  isOpen={showModal}
//               //  onClose={() => setShowModal(false)}
//              />
//            } */}

//             <h2>
//               {allPackageData[currentPackageIndex]?.pageTitle ||
//                 "Device Condition Form"}
//             </h2>

//             <h3 className="">
//               {allPackageData[currentPackageIndex]?.titleExplanation}
//             </h3>

//             <form className="form-content scrollbar-hidden">
//               {getPaginatedQuestions().map((q, index) => (
//                 <div className="form-box" key={q?.id || index}>
//                   <div className="question">
//                     <p className="question-text">
//                       {`${getQuestionNumber(index)}. ${q?.question}`}
//                       {(isConditionRelatedPackage) &&
//                         (q.type === "radio" || q.type === "icon-radio" || q.type === "dropdown") && (
//                           <span className="required-asterisk">*</span>
//                         )}
//                     </p>
//                     <p className="question-explaination-text">
//                       {q?.questionExplanation}
//                     </p>
//                   </div>
//                   {renderOptions(q)}
//                 </div>
//               ))}

//               {/* Main navigation buttons */}
//               <div className="button-box">
//                 <button
//                   type="button"
//                   className="pre-btn"
//                   onClick={handlePrevious}
//                 >
//                   {conditionsPaginationEnabled && currentConditionsPage > 0
//                     ? "Previous"
//                     : "Previous"}
//                 </button>
//                 <div className="fixed-btn">
//                   <button
//                     type="button"
//                     className="continue-btn enabled whitespace-nowrap overflow-hidden"
//                     onClick={handleContinue}
//                   >
//                     {getButtonText()}
//                   </button>

//                 </div>

//               </div>
//             </form>
//           </div>
//         </div>
//       </section>
//     </>
//   );
// }

// export default Step3;


import { useContext, useEffect, useRef, useState } from "react";
import "./Step3.css";
import { useNavigate, useParams } from "react-router-dom";
import DeviceImg from "../../../assets/images/Products/mobile.png";
import { UserContext } from "../../../Context/contextAPI";
import { toast } from "react-toastify";
import Cookies from "js-cookie";
import api from "../../../Utils/api";
import MobileCommonHeaderthree from "../../../Common/MobileCommonHeader/MobileCommonHeaderthree";

// ====== Transform questions ======
const transformQuestions = (apiQuestions) =>
  apiQuestions.map((q) => {
    let type = "radio";
    switch (q.questionType) {
      case "Radio":
        type = "radio";
        break;
      case "Multiple Select":
        type = "checkbox";
        break;
      case "Icon+Radio":
        type = "icon-radio";
        break;
      case "Icon+Select":
        type = "icon-checkbox";
        break;
      case "Dropdown":
        type = "dropdown";
        break;
      default:
        type = "radio";
    }

    const options =
      q.options?.map((opt, index) => ({
        id: opt._id || `${q._id}-${index}`,
        label: opt.label || opt.text || `Option ${index + 1}`,
        value: String(index),
        img: opt.iconUrl,
        description: opt.description || "",
      })) || [];

    return {
      id: q._id,
      question: q.questionName,
      questionExplanation: q.questionExplanation,
      type,
      options,
    };
  });

const extractAnsweredQuestions = (packageDataArray) => {
  const results = [];

  packageDataArray.forEach((pkg) => {
    const { packageName, packageType, questions, answers } = pkg;

    const answeredQuestions = Object.entries(answers || {})
      .map(([questionId, userAnswer]) => {
        const question = questions.find((q) => q.id === questionId);
        if (!question) return null;

        let selectedLabels = [];

        if (Array.isArray(userAnswer)) {
          selectedLabels = userAnswer
            .map((ans) => {
              const option = question.options.find((o) => o.value === ans);
              return option?.label;
            })
            .filter(Boolean);
        } else {
          const option = question.options.find((o) => o.value === userAnswer);
          if (option) selectedLabels = [option.label];
        }

        return {
          question: question.question,
          explanation: question.questionExplanation,
          selectedAnswers: selectedLabels,
        };
      })
      .filter(Boolean);

    if (answeredQuestions.length > 0) {
      results.push({
        packageName,
        packageType,
        questions: answeredQuestions,
      });
    }
  });

  return results;
};

function Step3() {
  let { slug } = useParams();
  const {
    packages,
    allPackageData,
    setAllPackageData,
    deviceInfo,
    userSelection,
    setIsLoginModalOpen,
    setanswersforMobile,
  } = useContext(UserContext);

  const assignedPackages = packages || [];
  const [currentPackageIndex, setCurrentPackageIndex] = useState(0);
  const navigate = useNavigate();

  const currentPackageData = allPackageData[currentPackageIndex] || {};
  const currentQuestions = currentPackageData?.questions || [];

  // ===== Conditions pagination =====
  const [conditionsPagination, setConditionsPagination] = useState({
    currentPage: 0,
    questionsPerPage: 3,
  });

  const isConditionRelatedPackage =
    currentPackageData.packageType?.includes("Condition") ||
    currentPackageData.packageName?.includes("Condition");

  const conditionsPaginationEnabled =
    isConditionRelatedPackage &&
    currentQuestions.length > conditionsPagination.questionsPerPage;

  const currentConditionsPage = conditionsPagination.currentPage;
  const conditionsQuestionsPerPage = conditionsPagination.questionsPerPage;
  const totalConditionsPages = Math.ceil(
    currentQuestions.length / conditionsQuestionsPerPage
  );

  const getPaginatedQuestions = () => {
    if (!conditionsPaginationEnabled) return currentQuestions;
    return currentQuestions.slice(
      currentConditionsPage * conditionsQuestionsPerPage,
      (currentConditionsPage + 1) * conditionsQuestionsPerPage
    );
  };

  const goToNextConditionsPage = () => {
    if (!validateCurrentConditionPage()) return;
    setConditionsPagination((prev) => ({
      ...prev,
      currentPage: prev.currentPage + 1,
    }));
  };

  const goToPrevConditionsPage = () => {
    setConditionsPagination((prev) => ({
      ...prev,
      currentPage: prev.currentPage - 1,
    }));
  };

  const resetConditionsPagination = () => {
    setConditionsPagination((prev) => ({
      ...prev,
      currentPage: 0,
    }));
  };

  useEffect(() => {
    resetConditionsPagination();
  }, [currentPackageIndex]);

  const getQuestionNumber = (index) => {
    if (!conditionsPaginationEnabled) return index + 1;
    return index + 1 + currentConditionsPage * conditionsQuestionsPerPage;
  };

  // ===== Refs + error tracking =====
  const questionRefs = useRef({});
  const [missingQuestions, setMissingQuestions] = useState([]);

  // ===== Validation =====
  const validateCurrentConditionPage = () => {
    const questionsToValidate = getPaginatedQuestions();

    const unansweredRequired = questionsToValidate.filter(
      (q) =>
        (q.type === "radio" || q.type === "icon-radio" || q.type === "dropdown") &&
        currentPackageData.answers[q.id] === undefined
    );

    if (unansweredRequired.length > 0) {
      const ids = unansweredRequired.map((q) => q.id);
      setMissingQuestions(ids);

      // Scroll to first missing question
      const firstId = ids[0];
      if (questionRefs.current[firstId]) {
        questionRefs.current[firstId].scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }

      toast.error(
        `Please answer ${unansweredRequired.length} required question(s) before continuing`
      );
      return false;
    }

    setMissingQuestions([]);
    return true;
  };

  const validateCurrentPackage = () => {
    const currentPackage = allPackageData[currentPackageIndex];

    if (!currentPackage.questions || currentPackage.questions.length === 0) {
      return true;
    }

    if (conditionsPaginationEnabled) {
      return validateCurrentConditionPage();
    }

    const unansweredRequired = currentPackage.questions.filter(
      (q) =>
        (q.type === "radio" || q.type === "icon-radio" || q.type === "dropdown") &&
        currentPackage.answers[q.id] === undefined
    );

    if (unansweredRequired.length > 0) {
      const ids = unansweredRequired.map((q) => q.id);
      setMissingQuestions(ids);

      const firstId = ids[0];
      if (questionRefs.current[firstId]) {
        questionRefs.current[firstId].scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }

      toast.error("Please answer all required questions before continuing");
      return false;
    }

    setMissingQuestions([]);
    return true;
  };

  // ===== Load questions from packages =====
  useEffect(() => {
    if (packages && packages.length > 0) {
      const transformed = packages.map((pkg) => ({
        packageId: pkg.packageId._id,
        packageName: pkg.packageId.packageName,
        packageType: pkg.packageId.packageType,
        pageTitle: pkg.packageId.pageTitle,
        titleExplanation: pkg.packageId.titleExplanation,
        questions: transformQuestions(pkg.packageId.questions || []),
        answers: {},
      }));
      setAllPackageData(transformed);
    } else {
      navigate(`${slug}/${userSelection.variantSlug}`);
    }
  }, [assignedPackages]);

  // ===== Handle option change =====
  const handleOptionChange = (questionId, optionValue, isMulti) => {
    setAllPackageData((prev) =>
      prev.map((pkg, index) => {
        if (index !== currentPackageIndex) return pkg;

        const prevAnswers = pkg.answers || {};
        let updatedAnswers;

        if (isMulti) {
          const current = prevAnswers[questionId] || [];
          updatedAnswers = {
            ...prevAnswers,
            [questionId]: current.includes(optionValue)
              ? current.filter((v) => v !== optionValue)
              : [...current, optionValue],
          };
        } else {
          updatedAnswers = {
            ...prevAnswers,
            [questionId]: optionValue,
          };
        }

        return {
          ...pkg,
          answers: updatedAnswers,
        };
      })
    );

    // remove error highlight if answered
    setMissingQuestions((prev) => prev.filter((id) => id !== questionId));
  };

  // ===== Render options =====
  const renderOptions = (q) => {
    const isMulti = q.type === "checkbox" || q.type === "icon-checkbox";
    const showIcons = q.type === "icon-radio" || q.type === "icon-checkbox";
    const isDropdown = q.type === "dropdown";
    const currentAnswers = allPackageData[currentPackageIndex]?.answers || {};
    const selected = currentAnswers[q.id] || (isMulti ? [] : "");

    if (isDropdown) {
      const selectedValue = currentAnswers[q.id] || "";
      return (
        <select
          className="dropdown-select"
          name={q.id}
          value={selectedValue}
          onChange={(e) => handleOptionChange(q.id, e.target.value, false)}
        >
          <option value="" disabled>
            Select an option
          </option>
          {q.options.map((opt) => (
            <option key={opt.id} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      );
    }

    return (
      <div
        className={`options ${
          showIcons
            ? "box-grid icon-option-container"
            : q.options.some(
                (opt) =>
                  (opt.label?.length || 0) > 40 ||
                  (opt.description?.length || 0) > 60
              )
            ? "long-text"
            : "short-text"
        }`}
      >
        {q.options.map((opt) => {
          const isSelected = isMulti
            ? selected.includes(opt.value)
            : selected === opt.value;

          return showIcons ? (
            <div
              key={opt.id}
              className={`select-box ${isSelected ? "selected" : ""}`}
              onClick={() => handleOptionChange(q.id, opt.value, isMulti)}
            >
              {opt.img && (
                <div className="icon-space">
                  <img src={opt.img} alt={opt.label} />
                </div>
              )}
              <label
                className="label-inside-icon"
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type={isMulti ? "checkbox" : "radio"}
                  name={q.id}
                  value={opt.value}
                  className="custom-radio"
                  checked={isSelected}
                  onChange={() => handleOptionChange(q.id, opt.value, isMulti)}
                />
                <span className="option-text">{opt.label}</span>
                {opt.description && (
                  <p className="option-text-des">{opt.description}</p>
                )}
              </label>
            </div>
          ) : (
            <label
              key={opt.id}
              className={`option ${isSelected ? "selected" : ""} option-with-des-box`}
              onClick={() => handleOptionChange(q.id, opt.value, isMulti)}
            >
              <input
                type={isMulti ? "checkbox" : "radio"}
                name={q.id}
                value={opt.value}
                checked={isSelected}
                onChange={() => handleOptionChange(q.id, opt.value, isMulti)}
                className="custom-radio"
                onClick={(e) => e.stopPropagation()}
              />
              <div className="option-input-flex">
                <span className="option-text">{opt.label}</span>
                {opt.description && (
                  <span className="option-text-des">{opt.description}</span>
                )}
              </div>
            </label>
          );
        })}
      </div>
    );
  };

  // ===== Transform answers for backend =====
  const transformAnswersForBackend = (answers, questions) => {
    const transformed = {};
    Object.entries(answers).forEach(([questionId, answerValue]) => {
      const question = questions.find((q) => q.id === questionId);
      if (!question) return;

      if (Array.isArray(answerValue)) {
        transformed[questionId] = answerValue.map((val) =>
          isNaN(val) ? val : Number(val)
        );
      } else {
        transformed[questionId] = isNaN(answerValue)
          ? answerValue
          : Number(answerValue);
      }
    });
    return transformed;
  };

  // ===== Save and price calculation =====
  const priceCalculationAndSave = async () => {
    try {
      const token = JSON.parse(Cookies.get("auth-token"));
      if (!token) return;

      if (!deviceInfo.deviceName) return;

      if (
        !userSelection?.cityId ||
        !userSelection?.cityName ||
        !userSelection?.wholeVariantId ||
        !userSelection?.variantId
      ) {
        toast.error("Please select city, device name and variant first");
        return;
      }

      const transformedPackageData = allPackageData.map((pkg) => ({
        ...pkg,
        answers: transformAnswersForBackend(pkg.answers || {}, pkg.questions),
      }));

      console.log("Transformed Package Data for Backend 🤔🤔🤔:", transformedPackageData);

      await api.post("/sell-module/user/price-estimation", {
        packagesAnswer: transformedPackageData,
        basePrice: 50000,
        userSelection,
        deviceName: deviceInfo.deviceName,
        deviceVariant: deviceInfo.variantDetail,
      });

      navigate(`/${slug}/price-summary`);
    } catch (error) {
      console.error("Error fetching final price:", error);
      toast.error("Error fetching final price");
    }
  };

  // ===== Continue / Previous =====
  const handleContinue = async () => {
    if (!validateCurrentPackage()) return;

    if (conditionsPaginationEnabled) {
      if (currentConditionsPage < totalConditionsPages - 1) {
        goToNextConditionsPage();
        return;
      }
    }

    if (currentPackageIndex < assignedPackages.length - 1) {
      setCurrentPackageIndex((i) => i + 1);
      return;
    }

    const savedToken = Cookies.get("auth-token");
    if (!savedToken) {
      setIsLoginModalOpen(true);
      return;
    }

    setanswersforMobile(extractAnsweredQuestions(allPackageData));

    await priceCalculationAndSave();
  };

  const handlePrevious = () => {
    if (conditionsPaginationEnabled && currentConditionsPage > 0) {
      goToPrevConditionsPage();
      return;
    }

    if (currentPackageIndex === 0) {
      navigate(`${slug}/${userSelection.variantSlug}`);
    } else {
      setCurrentPackageIndex((i) => i - 1);
    }
  };

  const getButtonText = () => {
    if (conditionsPaginationEnabled) {
      return currentConditionsPage < totalConditionsPages - 1
        ? "Next Page"
        : currentPackageIndex < assignedPackages.length - 1
        ? "Continue"
        : "Get Price";
    }
    return currentPackageIndex < assignedPackages.length - 1
      ? "Continue"
      : "Get Price";
  };

  return (
    <>
      <MobileCommonHeaderthree title="Calculation" />
      <section className="form-section mobile-pt-section">
        <div className="wrapper">
          {/* Left Side */}
          <div className="form-left">
            <div className="device-detail">
              <img src={deviceInfo?.devicePic || DeviceImg} alt="Device" />
              <div className="device-name">
                <h2>{deviceInfo?.deviceName}</h2>
                <span>{deviceInfo?.variantDetail}</span>
              </div>
            </div>

            <div className="form-details">
              <span>Device Details</span>
              {/* Optional: you can keep answered summary here */}
            </div>
          </div>

          {/* Right Side */}
          <div className="form-right">
            <h2>
              {allPackageData[currentPackageIndex]?.pageTitle ||
                "Device Condition Form"}
            </h2>

            <h3>{allPackageData[currentPackageIndex]?.titleExplanation}</h3>

            <form className="form-content scrollbar-hidden">
              {getPaginatedQuestions().map((q, index) => (
                <div
                  className="form-box"
                  key={q?.id || index}
                  ref={(el) => (questionRefs.current[q.id] = el)}
                >
                  <div className="question">
                    <p className="question-text">
                      {`${getQuestionNumber(index)}. ${q?.question}`}
                      {isConditionRelatedPackage &&
                        (q.type === "radio" ||
                          q.type === "icon-radio" ||
                          q.type === "dropdown") && (
                          <span className="required-asterisk">*</span>
                        )}
                    </p>
                    <p className="question-explaination-text">
                      {q?.questionExplanation}
                    </p>
                  </div>
                  {renderOptions(q)}

                  {missingQuestions.includes(q.id) && (
                    <p className="error-text" >Please fill required question</p>
                  )}
                </div>
              ))}

              {/* Main navigation buttons */}
              <div className="button-box">
                <button
                  type="button"
                  className="pre-btn"
                  onClick={handlePrevious}
                >
                  {conditionsPaginationEnabled && currentConditionsPage > 0
                    ? "Previous"
                    : "Previous"}
                </button>
                <div className="fixed-btn">
                  <button
                    type="button"
                    className="continue-btn enabled whitespace-nowrap overflow-hidden"
                    onClick={handleContinue}
                  >
                    {getButtonText()}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </section>
    </>
  );
}

export default Step3;
