import React, { useState } from "react";
import styles from "./Footer.module.css";

import footerstore1 from "../../assets/images/icons/playstore.png";
import footerstore2 from "../../assets/images/icons/appstore.png";
import facebookIcon from "../../assets/images/icons/facebook.png";
import instagramIcon from "../../assets/images/icons/instagram.png";
import xIcon from "../../assets/images/icons/x.png";
import youtubeIcon from "../../assets/images/icons/youtube.png";
// import chatIcon from "../../assets/images/icons/chat.png";
import logo from "../../assets/newicons/logo.svg";
import { FaAngleDown, FaAngleUp } from "react-icons/fa";
import chatIcon from "../../assets/QuickSellNewIcons/Info.svg"
import uparrow from "../../assets/QuickSellNewIcons/BackArrowwithouttail.svg";
import downarrow from "../../assets/QuickSellNewIcons/BackArrowwithouttail.svg";
import FooterContent from "./FooterContent";
import { Link } from "react-router-dom";

const FooterSection = ({ title, links }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className={styles.footerSection}>
      <div
        className={styles.footerSectionHeader}
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3>{title}</h3>
        {/* <span>{isOpen ? {uparrow} : {downarrow}}</span> */}
        { isOpen ?
          <img src={downarrow} alt="" className={styles.downarrow} /> :
          <img src={uparrow} alt="" className={styles.uparrow} />
        }
        
       
      </div>
      {isOpen && (
        <div className={styles.footerLinks}>
          {links.map((link, idx) => (
            <a href="#" key={idx}>
              {link}
            </a>
          ))}
        </div>
      )}
    </div>
  );
};
const Footer = () => {
  return (
    <>
    <FooterContent/>
    
      <footer className={`${styles.footerContainer} md-none`}>
        <div className={styles.footerContent}>
          {/* Services Section */}
          <div className={styles.footerColumn}>
            <h3 className={styles.footerHeading}>Services</h3>
            <div className={styles.footerLinks}>
              <a href="#">Sell Phone</a>
              <a href="#">Sell Tablet</a>
              <a href="#">Sell Laptop</a>
              <a href="#">Sell Smartwatch</a>
              <a href="#">Sell Earbuds</a>
              <a href="#">Sell Gaming Console</a>
              <a href="#">Recycle Phone/Other Device</a>
              <a href="#">Retire Phone</a>
              <a href="#">Buy Phone</a>
              <a href="#">Buy Accessories</a>
            </div>
          </div>

          {/* About Section */}
          <div className={styles.footerColumn}>
            <h3 className={styles.footerHeading}>About</h3>
            <div className={styles.footerLinks}>
              <Link to="/About-us">About us</Link>
              <a href="#">Impact</a>
              <a href="#">Press Release</a>
              <a href="#">Blogs</a>
              <a href="#">Career</a>
            </div>
          </div>

          {/* Help Center */}
          <div className={styles.footerColumn}>
            <h3 className={styles.footerHeading}>Help Center</h3>
            <div className={styles.footerLinks}>
              <a href="#">FAQ</a>
              <a href="#">Contact Us</a>
              <Link to="/Refund">Return & Refund</Link>
              <a href="#">Shipment</a>
              <a href="#">Warranty Policy</a>
            </div>
          </div>

          {/* Law and Orders */}
          <div className={styles.footerColumn}>
            <h3 className={styles.footerHeading}>Law and Orders</h3>
            <div className={styles.footerLinks}>
              <Link to="/terms">Terms of Use</Link>
              <a href="#">Terms and Conditions</a>
              <Link to="/Cookies">Cookies</Link>
              <a href="#">Privacy Policy</a>
              <a href="#">Cookies Policy</a>
            </div>
          </div>

          {/* Others */}
          <div className={styles.footerColumn}>
            <h3 className={styles.footerHeading}>Others</h3>
            <div className={styles.footerLinks}>
              <a href="#">Register Warranty</a>
              <a href="#">Claim Warranty</a>
              <a href="#">Become Partner</a>
              <a href="#">Frenchies</a>
              <a href="#">Bulk Buying</a>
              <a href="#">Become Partner Store</a>
            </div>
          </div>

          {/* Logo and Social Icons */}
          <div className={styles.footerColumn}>
            <a href="#">
              <img src={logo} alt="Logo" className={styles.logo} />
            </a>
            <p>follow us on</p>
            <div className={styles.socialIcons}>
              <a href="#">
                <img src={facebookIcon} alt="Facebook" />
              </a>
              <a href="#">
                <img src={instagramIcon} alt="Instagram" />
              </a>
              <a href="#">
                <img src={xIcon} alt="X" />
              </a>
              <a href="#">
                <img src={youtubeIcon} alt="YouTube" />
              </a>
            </div>
            <button className={styles.chatButton}>
              <img src={xIcon} alt="Chat Icon" /> Chat with us
            </button>
          </div>
        </div>

        {/* Footer Bottom Section */}
        <div className={styles.footerBottom}>
          <p>© 2025 Quick Mobile</p>
          <div className={styles.footerRightBox}>
            <a href="#">
              <img src={footerstore1} alt="Play Store" />
            </a>
            <a href="#">
              <img src={footerstore2} alt="App Store" />
            </a>
          </div>
        </div>
      </footer>
      <footer className={`${styles.footerContainer} md-block`}>
        <div className={styles.mobileFooterContent}>
          <FooterSection
            title="Services"
            links={[
              "Sell Phone",
              "Sell Tablet",
              "Sell Laptop",
              "Sell Smartwatch",
              "Sell Earbuds",
              "Sell Gaming Console",
              "Recycle Phone/Other Device",
              "Retire Phone",
              "Buy Phone",
              "Buy Accessories",
            ]}
          />
          <FooterSection
            title="About"
            links={["About Us", "Impact", "Press Release", "Blogs", "Career"]}
          />
          <FooterSection
            title="Help Center"
            links={[
              "FAQ",
              "Contact Us",
              "Return & Refund",
              "Shipment",
              "Warranty Policy",
            ]}
          />
          <FooterSection
            title="Law and Order"
            links={[
              "Terms to Use",
              "Terms and Conditions",
              "Cookies",
              "Privacy Policy",
              "Cookies Policy",
            ]}
          />
          <FooterSection
            title="Others"
            links={[
              "Register Warranty",
              "Claim Warranty",
              "Become Partner",
              "Frenchies",
              "Bulk Buying",
              "Become Partner Store",
            ]}
          />

          <div className={styles.logoSection}>
            <img src={logo} alt="Logo" className={styles.logo} />
            <p>follow us on</p>

            <div className={styles.socialIcons}>
              <a href="#">
                <img src={facebookIcon} alt="Facebook" />
              </a>
              <a href="#">
                <img src={instagramIcon} alt="Instagram" />
              </a>
              <a href="#">
                <img src={xIcon} alt="X" />
              </a>
              <a href="#">
                <img src={youtubeIcon} alt="YouTube" />
              </a>
            </div>
          </div>
          <div className={styles.chatbox}>
            <img src={chatIcon} alt="" />
            <div className={styles.chatText}>
              <h5>Chat With Us</h5>
              <p>We are here to help you</p>
            </div>
          </div>

          <div className={styles.footerBottom}>
            <p>© 2025 Quick Mobile</p>
            <div className={styles.footerRightBox}>
              <a href="#">
                <img src={footerstore1} alt="Play Store" />
              </a>
              <a href="#">
                <img src={footerstore2} alt="App Store" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
