import React, { useContext, useState } from "react";
import { MdClose, MdPhoneAndroid } from "react-icons/md";
import axios from "axios";
import Cookies from "js-cookie";
import { toast } from "react-toastify";
import { UserContext } from "../../../Context/contextAPI";
import api from "../../../Utils/api";
import styles from "./SignUpModal.module.css";

const SignUpModal = ({ isOpen, onClose }) => {
  const [mobile, setMobile] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState(Array(6).fill(""));
  const { setUser } = useContext(UserContext);

  const handleSendOtp = () => {
    if (mobile.length === 10) {
      setOtpSent(true);
    } else {
      toast.error("Enter a valid 10-digit mobile number");
    }
  };

  const handleOtpChange = (index, value) => {
    if (/^\d?$/.test(value)) {
      const updated = [...otp];
      updated[index] = value;
      setOtp(updated);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/sell-module/user/signUp", {
        phone: mobile,
        verifyOtp: otp.join(""),
      });

      if (response.data) {
        alert(`${response?.data?.message}`);
        const token = response.data.token;
        Cookies.set("auth-token", JSON.stringify(token), {
          expires: 2,
          secure: true,
          sameSite: "strict",
        });
        setUser(response.data?.user);
      }
      toast.success("Signed up successfully");
      onClose();
    } catch (err) {
      console.log("Error Occured", err);
      toast.error("Error verifying OTP");
    }
  };

  if (!isOpen) return null;

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <button className={styles.closeButton} onClick={onClose}>
          <MdClose />
        </button>

        <div className={styles.header}>
          <h2 className={styles.title}>Sign Up</h2>
          <p className={styles.subtitle}>Enter your mobile number to sign up.</p>
        </div>

        <div className={styles.inputGroup}>
          <MdPhoneAndroid className={styles.icon} />
          <input
            type="text"
            maxLength="10"
            placeholder="Enter your mobile number"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            className={styles.input}
          />
        </div>

        {otpSent && (
          <div className={styles.otpContainer}>
            {otp.map((digit, index) => (
              <input
                key={index}
                type="text"
                maxLength="1"
                className={styles.otpInput}
                value={digit}
                onChange={(e) => handleOtpChange(index, e.target.value)}
              />
            ))}
          </div>
        )}

        <button
          onClick={otpSent ? handleSubmit : handleSendOtp}
          className={styles.submitButton}
        >
          {otpSent ? "Verify & Sign Up" : "Send OTP"}
        </button>
      </div>
    </div>
  );
};

export default SignUpModal;
