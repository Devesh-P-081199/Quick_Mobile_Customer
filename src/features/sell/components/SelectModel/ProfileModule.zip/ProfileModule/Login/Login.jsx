import React, { useContext, useState } from "react";
import { MdPhoneAndroid, MdLock } from "react-icons/md";
import styles from "./Login.module.css"; // Reusing the same CSS module
import { NavLink, useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { toast } from "react-toastify";
import api from "../../../Utils/api";
import { UserContext } from "../../../Context/contextAPI";

const Login = () => {
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const { setUser } = useContext(UserContext);
  const navigate=useNavigate();
  const handleLogin = async(e) => {
    e.preventDefault();
    if (mobile.length !== 10) {
      toast.warning("Please enter a valid 10-digit mobile number.");
      return;
    }
    if (!password) {
      toast.error("Please enter your password.");
      return;
    }
  
    try {
      const userLogin = await api.post("/sell-module/user/login", { phone: mobile, password });
      console.log("User Login", userLogin.data);
     
      if (userLogin.data) {
        const token = userLogin?.data?.token;
        Cookies.set("auth-token", JSON.stringify(token), {
          expires: 2,
          secure: true,
          sameSite: "strict",
        });
        // console.log("response.data?.user",response.data?.user)
        setUser(userLogin.data?.user);
      }
      toast.success("Login Success");
      navigate("/my-profile-orders");
      // Navigate to dashboard or wherever you want
    } catch (error) {
      console.log("Error occured", error);
      toast.error(`${error.response.data.message}`);
    }
  };
  
  return (
    <div className={styles.signUpWrapper}>
      <div className={styles.leftPanel}>
        <div className={styles.leftHeader}>
                    <h1 className={styles.brand}>Quick <span className="color-orange">Mobile </span> </h1>
          
          <h2 className={styles.tagline}>Welcome Back</h2>
          <p className={styles.subtext}>
            Login to access your Quick Mobile dashboard.
          </p>
        </div>
        <div className={styles.leftButtons}>
          <button className={styles.primaryBtn}>1. Login your account</button>
          {/* <button className={styles.secondaryBtn}>Sell Now</button> */}
        </div>
      </div>

      <div className={styles.formCard}>
        <div className={styles.formContainer}>
          <div className={styles.formHeader}>
            <h2 className={styles.formTitle}>Login to Account</h2>
            <p className={styles.formSubtitle}>
              Enter your credentials to continue.
            </p>
          </div>

          {/* Mobile Number */}
          <div className={styles.inputGroup}>
            <div className={styles.inputRow}>
              <div className={styles.icon}>
                <MdPhoneAndroid size={24} />
              </div>
              <div className={styles.inputContent}>
                <label htmlFor="mobile" className={styles.label}>
                  Mobile Number
                </label>
                <input
                  type="text"
                  id="mobile"
                  maxLength="10"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className={styles.mobileInput}
                  placeholder="Enter your mobile number"
                />
              </div>
            </div>
          </div>

          {/* Password */}
          <div className={styles.inputGroup}>
            <div className={styles.inputRow}>
              <div className={styles.icon}>
                <MdLock size={24} />
              </div>
              <div className={styles.inputContent}>
                <label htmlFor="password" className={styles.label}>
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={styles.mobileInput}
                  placeholder="Enter your password"
                />
              </div>
            </div>
          </div>

          <button className={styles.submitBtn} onClick={handleLogin}>
            Log In
          </button>

          <p className={styles.loginLink}>Don't have an account? 
          <NavLink to="/signup" className={styles.loginLink}>
             Sign Up
          </NavLink>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
